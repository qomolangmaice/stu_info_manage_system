#ifndef __EEPROM_H
#define __EEPROM_H
#include "sys.h"
#ifdef   __cplusplus   
  extern   "C"   {   
#endif 
#define AT24C02_DATA_ADDR 1
#define AT24C02_PAGE_SIZE 8
#define EEPROM_DATA_ADDR  AT24C02_DATA_ADDR
#define EEPROM_PAGE_SIZE  AT24C02_PAGE_SIZE
u8  EEPROMInit(void);
u8 EEPROMReadData(u16 eEp, u8 *dst, u16 len);
u8 EEPROMWriteData(u16 eEp, u8 *src, u16 len);

#ifdef   __cplusplus   
	}   
#endif
#endif
