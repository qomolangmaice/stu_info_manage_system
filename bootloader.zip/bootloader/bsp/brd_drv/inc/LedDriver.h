#ifndef __LED_H
#define __LED_H
#include "sys.h"
#if HOPE_WIND_EN>0
#define LED0 PGout(5)	
#define LED1 PGout(6)	
#else

#if QIMING_BOARD>0
#define LED0 PEout(3)	 
#define LED1 PEout(4)	 
#define LED2 PGout(9)	  

#else
//LED�˿ڶ���
#define LED0 PFout(9)	// DS0
#define LED1 PFout(10)	// DS1	 
#endif	 
#endif

void LED_Init(void);//��ʼ��		 				    
#endif
