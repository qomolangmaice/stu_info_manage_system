#ifndef __rx8025_h__
#define __rx8025_h__
#include "sys.h"

__packed typedef struct
{
	u8 year;
	u8 month;
	u8 day;
	u8 hour;
	u8 minute;
	u8 second;
}DateTimeType;

__packed typedef struct
{
	u8 year;
	u8 month;
	u8 day;
	u8 hour;
	u8 minute;
}ZJTimeType;
extern void Rx8025Init(void);
extern u8 Rx8025THWInit(void);
extern u8 Rx8025SetTime(DateTimeType dt);

extern DateTimeType Rx8025GetTime(void);
extern DateTimeType Rx8025GetBCDTime(void);
void RtcSetTime(u32 time);


u32 DataTimeToSecond(DateTimeType dt);
DateTimeType SecondToDataTime(u32 second);

extern int diffSysSecond(u32 second);
extern int DateTimeDayCmp(DateTimeType *pDateTime, ZJTimeType *pZJTime);
extern int DateTimeCmp(DateTimeType *pdatetime1, DateTimeType *pdatetime2);

extern u8 IsDateTimeValid(DateTimeType *pDateTime);

extern void GetDateTime(DateTimeType *pDateTime);
extern void RtcAddSecond(u8 arg);
extern void ZJTimeAddDay(ZJTimeType *pZJTime, u8 day);
extern void GetDateByDays(DateTimeType *pDateTime, u32 days);
extern void DateTimeAddMin(DateTimeType *pdatetime, u16 min);
extern void DateTimeDecDay(DateTimeType *pdatetime);
extern void ZJTimeAddMonth(ZJTimeType *pZJTime, u8 month);
extern void ZJTimeAddMinute(ZJTimeType *pZJTime, u8 minute);
extern void DateTimeDecHour(DateTimeType *pdatetime);
extern void DateTimeAddMonth(DateTimeType *pDateTime, u8 month);
extern void CalibrateTimeBy8025(void);
extern void GetDateTimeByHours(DateTimeType *pdatetime, u32 hours);
extern void GetDateTimeByMinutes(DateTimeType *pdatetime, u32 minutes);

extern u8 CalWeek(DateTimeType Dt);
extern u8 GetMaxDay(u16 year, u8 month);
extern u16 GetDaysByDate(u16 year, u8 month, u8 day);
extern u32 GetHoursByDateTime(DateTimeType *pdatetime);
extern u32 GetMinutesByDateTime(DateTimeType *pdatetime);
#endif
